// حالة الاتصال: فورية، بدون أي طلب شبكة أو اعتماد على موقع خارجي
(function () {
  var stat = document.querySelector('#stat');
  if (!stat) return;

  function update() {
    var on = navigator.onLine;
    stat.textContent = on ? "Online" : "Offline";
    stat.style.background = on ? "#1eaff3" : "#e71818";
  }

  window.addEventListener("online", update);
  window.addEventListener("offline", update);
  update();
})();
