package com.navixium.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * ui  : واجهة NAVIXIUM (ملف HTML من مجلد assets)
 * web : متصفح حقيقي (WebView) يوضع فوق منطقة النتائج بدل الـ iframe
 */
class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var ui: WebView
    private lateinit var web: WebView
    private lateinit var dm: DownloadManager

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("downloads", MODE_PRIVATE) }

    @Volatile private var curUrl = ""
    @Volatile private var curTitle = ""

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val prevBytes = HashMap<Long, Long>()
    private val prevTime = HashMap<Long, Long>()
    private val speeds = HashMap<Long, Double>()
    private var lastJson = ""
    private var hasActive = false

    private val poller = object : Runnable {
        override fun run() {
            pushDownloads(false)
            handler.postDelayed(this, if (hasActive) 700L else 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager

        root = FrameLayout(this)
        ui = WebView(this)
        web = WebView(this)
        root.addView(ui, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val lp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        lp.topMargin = (74 * resources.displayMetrics.density).toInt()   // ارتفاع شريط البحث + شريط الحالة
        web.visibility = View.GONE
        root.addView(web, lp)
        setContentView(root)

        setupUi()
        setupWeb()

        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }

        ui.loadUrl("file:///android_asset/navixium.html")
        handler.post(poller)
    }

    // ---------- نوافذ التنبيه (alert / confirm) ----------
    private open inner class BaseChrome : WebChromeClient() {
        override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setOnCancelListener { result?.cancel() }
                .show()
            return true
        }

        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setNegativeButton("Cancel") { _, _ -> result?.cancel() }
                .setOnCancelListener { result?.cancel() }
                .show()
            return true
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupUi() {
        ui.settings.javaScriptEnabled = true
        ui.settings.domStorageEnabled = true
        ui.setBackgroundColor(Color.parseColor("#1A2238"))
        ui.webChromeClient = BaseChrome()
        ui.addJavascriptInterface(Bridge(), "Android")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.userAgentString = s.userAgentString.replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.setBackgroundColor(Color.WHITE)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val sc = u.scheme ?: return false
                if (sc == "http" || sc == "https" || sc == "about" || sc == "file" || sc == "data" || sc == "blob") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                curUrl = url ?: ""
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                curUrl = url ?: curUrl
                curTitle = view?.title ?: ""
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request != null && request.isForMainFrame) {
                    val html = "<body style='font-family:sans-serif;background:#1a2238;color:#fff;text-align:center;padding-top:30%'>" +
                        "<h3>Cannot open this page</h3><p>Check your connection and try again.</p></body>"
                    view?.loadDataWithBaseURL(request.url.toString(), html, "text/html", "UTF-8", request.url.toString())
                }
            }
        }

        web.webChromeClient = object : BaseChrome() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                curTitle = title ?: ""
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                showCustomView(view, callback)
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }

        // أي تنزيل يبدأ من أي موقع يذهب إلى مدير التنزيلات ويظهر في قائمتك
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            enqueue(url, userAgent, contentDisposition, mimeType)
        }
    }

    @Suppress("DEPRECATION")
    private fun showCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
        if (customView != null || view == null) {
            callback?.onCustomViewHidden()
            return
        }
        customView = view
        customCb = callback
        root.addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    @Suppress("DEPRECATION")
    private fun hideCustomView() {
        customView?.let { root.removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    // ---------- الجسر بين واجهة HTML والتطبيق ----------
    inner class Bridge {
        @JavascriptInterface
        fun openUrl(url: String) { runOnUiThread { web.loadUrl(url) } }

        @JavascriptInterface
        fun showWeb(on: Boolean) { runOnUiThread { web.visibility = if (on) View.VISIBLE else View.GONE } }

        @JavascriptInterface
        fun reloadWeb() { runOnUiThread { web.reload() } }

        @JavascriptInterface
        fun currentUrl(): String = curUrl

        @JavascriptInterface
        fun currentTitle(): String = curTitle

        @JavascriptInterface
        fun download(url: String) { runOnUiThread { enqueue(url, null, null, null) } }

        @JavascriptInterface
        fun refreshDownloads() { runOnUiThread { pushDownloads(true) } }

        @JavascriptInterface
        fun removeDownload(id: String) { runOnUiThread { id.toLongOrNull()?.let { removeDl(it) } } }

        @JavascriptInterface
        fun openDownload(id: String) { runOnUiThread { id.toLongOrNull()?.let { openDl(it) } } }

        @JavascriptInterface
        fun record() { runOnUiThread { startSpeech() } }
    }

    // ---------- التنزيلات ----------
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun ids(): HashSet<String> = HashSet<String>(prefs.getStringSet("ids", null) ?: emptySet<String>())

    private fun saveIds(set: Set<String>) {
        prefs.edit().putStringSet("ids", HashSet<String>(set)).apply()
    }

    private fun uniqueName(n: String): String {
        if (Build.VERSION.SDK_INT >= 29) return n
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val dot = n.lastIndexOf('.')
        val base = if (dot > 0) n.substring(0, dot) else n
        val ext = if (dot > 0) n.substring(dot) else ""
        var out = n
        var i = 1
        while (File(dir, out).exists()) {
            out = "$base ($i)$ext"
            i++
        }
        return out
    }

    private fun enqueue(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            val name = uniqueName(URLUtil.guessFileName(url, contentDisposition, mimeType))
            val req = DownloadManager.Request(Uri.parse(url))
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!mimeType.isNullOrEmpty()) req.setMimeType(mimeType)
            if (!userAgent.isNullOrEmpty()) req.addRequestHeader("User-Agent", userAgent)
            if (curUrl.startsWith("http")) req.addRequestHeader("Referer", curUrl)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            val id = dm.enqueue(req)
            val set = ids()
            set.add(id.toString())
            saveIds(set)
            toast("Download started: $name")
            pushDownloads(true)
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot download this file", Toast.LENGTH_LONG).show()
        }
    }

    private fun pushDownloads(force: Boolean) {
        val arr = JSONArray()
        val gone = HashSet<String>()
        val now = SystemClock.elapsedRealtime()
        var active = false
        val all = ids().mapNotNull { it.toLongOrNull() }.sortedDescending()

        for (id in all) {
            val c: Cursor? = dm.query(DownloadManager.Query().setFilterById(id))
            if (c == null || !c.moveToFirst()) {
                c?.close()
                gone.add(id.toString())
                continue
            }
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val title = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "file"
            val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            c.close()

            var state = "loading"
            if (status == DownloadManager.STATUS_SUCCESSFUL) state = "done"
            if (status == DownloadManager.STATUS_FAILED) state = "error"

            if (state == "loading") {
                active = true
                val pb = prevBytes[id]
                val pt = prevTime[id]
                if (pb != null && pt != null && now > pt) {
                    val inst = (got - pb) * 1000.0 / (now - pt)
                    val old = speeds[id]
                    speeds[id] = if (old == null) inst else old * 0.7 + inst * 0.3
                }
                prevBytes[id] = got
                prevTime[id] = now
            }

            val o = JSONObject()
            o.put("id", id.toString())
            o.put("name", title)
            o.put("state", state)
            o.put("received", got)
            o.put("total", if (total > 0) total else 0L)
            o.put("size", if (total > 0) total else got)
            o.put("speed", speeds[id] ?: 0.0)
            if (state == "error") o.put("err", "Download failed (code $reason)")
            arr.put(o)
        }

        if (gone.isNotEmpty()) {
            val set = ids()
            set.removeAll(gone)
            saveIds(set)
        }
        hasActive = active
        val json = arr.toString()
        if (force || json != lastJson) {
            lastJson = json
            ui.evaluateJavascript("window.onDownloads&&onDownloads(" + JSONObject.quote(json) + ")", null)
        }
    }

    private fun removeDl(id: Long) {
        try { dm.remove(id) } catch (e: Exception) { }
        val set = ids()
        set.remove(id.toString())
        saveIds(set)
        prevBytes.remove(id)
        prevTime.remove(id)
        speeds.remove(id)
        pushDownloads(true)
    }

    private fun openDl(id: Long) {
        val uri = dm.getUriForDownloadedFile(id)
        if (uri == null) {
            toast("File not found")
            return
        }
        val mime = dm.getMimeTypeForDownloadedFile(id) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, mime)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("No app can open this file")
        }
    }

    // ---------- البحث الصوتي ----------
    @Suppress("DEPRECATION")
    private fun startSpeech() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
        try {
            startActivityForResult(i, 7)
        } catch (e: Exception) {
            toast("Voice search is not available")
            sendSpeech("")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7) {
            var t = ""
            if (resultCode == RESULT_OK) {
                t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: ""
            }
            sendSpeech(t)
        }
    }

    private fun sendSpeech(t: String) {
        ui.evaluateJavascript("window.onSpeech&&onSpeech(" + JSONObject.quote(t) + ")", null)
    }

    // ---------- زر الرجوع ----------
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (customView != null) {
            hideCustomView()
            return
        }
        if (web.visibility == View.VISIBLE && web.canGoBack()) {
            web.goBack()
            return
        }
        ui.evaluateJavascript("onAndroidBack()") { r ->
            if (r != "true") finish()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        ui.destroy()
        web.destroy()
        super.onDestroy()
    }
}
